# ML-Practical
ML Practical Course Repository RUG
