import numpy as np 
import random
import torch
import torchvision
import torch.nn as nn
from torchvision import datasets, transforms
from sklearn.model_selection import KFold
import matplotlib.pyplot as plt
from torch.utils.data import random_split, DataLoader
import torch.nn.functional as F
from torch.utils.data import Subset
import os
import time
from tqdm import tqdm
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, SubsetRandomSampler
from sklearn.model_selection import KFold
from tqdm import tqdm
import multiprocessing

# ======================= SMALL DATASET ======================= #
def get_labels_from_loader(loader):
    labels = []
    for _, label in loader:
        labels.extend(label.tolist())
    return labels

def get_subset_with_n_classes(original_dataset, n_classes, batch_size=64):
    # Check if the dataset is a Subset
    if isinstance(original_dataset, Subset):
        # Create a DataLoader to extract labels from the Subset
        subset_loader = DataLoader(original_dataset, batch_size=batch_size, shuffle=False)
        # Extract labels
        targets = get_labels_from_loader(subset_loader)
    else:
        # Try to access labels through the targets attribute
        try:
            targets = original_dataset.targets
        except AttributeError:
            # If targets attribute doesn't exist, use __getitem__ method
            targets = [original_dataset[i][1] for i in range(len(original_dataset))]

    # Find the unique classes and select the first n
    unique_classes = torch.unique(torch.tensor(targets))
    selected_classes = unique_classes[:n_classes].tolist()

    # Get the indices of samples belonging to the selected classes
    selected_indices = [i for i, t in enumerate(targets) if t in selected_classes]

    # Handle if the dataset is already a Subset
    if isinstance(original_dataset, Subset):
        # Adjust indices to map to the original dataset
        original_indices = [original_dataset.indices[i] for i in selected_indices]
        # Create a new Subset from the original dataset
        subset = Subset(original_dataset.dataset, original_indices)
    else:
        # Create a new Subset
        subset = Subset(original_dataset, selected_indices)

    return subset

# =======================   CNN MODEL    ======================= #
class SimpleCNN(nn.Module):
    def __init__(self, num_classes):
        super(SimpleCNN, self).__init__()
        # Input shape: [batch_size, 3, 256, 256]
        self.conv1 = nn.Conv2d(in_channels=3, out_channels=32, kernel_size=3, stride=1, padding=1)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)
        self.conv2 = nn.Conv2d(in_channels=32, out_channels=64, kernel_size=3, stride=1, padding=1)
        # Fully connected layer
        self.fc1 = nn.Linear(64 * 64 * 64, 512)
        self.fc2 = nn.Linear(512, 512)
        self.fc3 = nn.Linear(512, num_classes)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = x.view(-1, 64 * 64 * 64)  # Flatten the tensor
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x
    
def train_fold(fold, train_indices, val_indices, subset_train, model, criterion, optimizer, num_epochs, batch_size, num_workers, num_folds, num_classes,learning_rate, device):
    # print(f"Fold {fold + 1}/{num_folds}")

    model = SimpleCNN(num_classes).to(device)  # Ensure to move the model to the correct device
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    # Split the data into training and validation sets for this fold
    train_sampler = SubsetRandomSampler(train_indices)
    val_sampler = SubsetRandomSampler(val_indices)

    train_loader = DataLoader(subset_train, batch_size=batch_size, sampler=train_sampler, num_workers=num_workers)
    val_loader = DataLoader(subset_train, batch_size=batch_size, sampler=val_sampler, num_workers=num_workers)

    best_val_accuracy_fold = 0.0

    for epoch in tqdm(range(num_epochs), desc="Training", unit="epoch"):
        # Training loop
        model.train()
        for images, labels in train_loader:
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

        # Validation loop
        model.eval()
        total_correct = 0
        total_samples = 0
        with torch.no_grad():
            for images, labels in val_loader:
                outputs = model(images)
                _, predicted = torch.max(outputs, 1)
                total_samples += labels.size(0)
                total_correct += (predicted == labels).sum().item()

        val_accuracy = total_correct / total_samples
        print(f"Epoch [{epoch + 1}/{num_epochs}] - Validation Accuracy: {val_accuracy:.4f}")

        # Check if this model has the best validation accuracy
        if val_accuracy > best_val_accuracy_fold:
            best_val_accuracy_fold = val_accuracy

    return best_val_accuracy_fold, model.state_dict()


def main():
    print("Starting - Food101")
    # ======================= PYTHON SETTINGS ======================= #
    # =======================   GPU or CPU    ======================= #
    device = None
    # Check if GPU is available -> CUDA
    if torch.cuda.is_available():
        device = torch.device("cuda")
        print("There are %d GPU(s) available." % torch.cuda.device_count())
        print("We will use the GPU:", torch.cuda.get_device_name(0))

    # Apple Silicon GPU
    if torch.backends.mps.is_available():
        mps_device = torch.device("mps")
        out = torch.ones(1, device=mps_device)
        print (out)
        print ("MPS device found. - Apple Silicon GPU")
        device = mps_device
    else:
        print ("MPS device not found.")

    # =======================   Ranom Seeds   ======================= #
    # Set random seed for reproducibility
    seed = 42
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    # =============================================================== #


    # ======================= NORMALIZE PARAMS ======================= #
    transform = transforms.Compose([
        transforms.Resize((256, 256)),  # Resize images to a consistent size
        transforms.ToTensor(),          # Convert images to tensors
        transforms.Normalize(           # Normalize the images
            # average values of the red, green, 
            # and blue channels across all images in the ImageNet dataset.
            mean=[0.485, 0.456, 0.406], 
            # standard deviation of the red, green, and blue 
            # channels across all images in the ImageNet dataset.
            std=[0.229, 0.224, 0.225]   
        )
    ])
    # =============================================================== #

    # ======================= LOAD MAIN DATASET ======================= #
    # Download and load the Food101 dataset
    train_dataset = torchvision.datasets.Food101(
        root='./data',                 # Directory to save the downloaded data
        split='train',
        download=True,                 # Download the data if not present
        transform=transform            # Apply the transform to the data
    )

    test_dataset = torchvision.datasets.Food101(
        root='./data',                 # Directory to save the downloaded data
        split='test',
        download=True,                 # Download the data if not present
        transform=transform            # Apply the transform to the data
    )
    # =============================================================== #
    print("Data Successfully Loaded - Food101")


    # Get a subset with the first n classes
    n = 5  # For example, get the first 5 classes
    subset_train = get_subset_with_n_classes(train_dataset, n)
    subset_test = get_subset_with_n_classes(test_dataset, n)
    print("Dataset Number for Training:", n)
    # =============================================================== #

    start_time = time.time()  # Record the start time

    # Set the number of workers for data loading (adjust according to your system)
    num_workers = 10
    num_folds = 10
    num_epochs = 20
    batch_size = 64
    learning_rate = 0.001
    num_classes = n

    kf = KFold(n_splits=num_folds, shuffle=True, random_state=seed)

    best_model = None
    best_val_accuracy = 0.0

    processes = []
    print("Starting K-Fold Cross-Validation")
    for fold, (train_indices, val_indices) in tqdm(enumerate(kf.split(subset_train)), total=num_folds, desc='Cross Validation'):
        p = multiprocessing.Process(target=train_fold, 
                    args=(fold, train_indices, val_indices, 
                        subset_train, SimpleCNN(num_classes), 
                        nn.CrossEntropyLoss(), torch.optim.Adam, 
                        num_epochs, batch_size, num_workers, num_folds,
                        num_classes, learning_rate, device))
        p.start()
        processes.append(p)

    for p in processes:
        p.join()

    # After K-fold cross-validation, use the best model for testing
    model_instance = SimpleCNN(num_classes)
    model_instance.load_state_dict(best_model)
    model_instance.eval()

    end_time = time.time()  # Record the end time
    elapsed_time = end_time - start_time

    print(f"Total execution time: {elapsed_time:.2f} seconds")


if __name__ == "__main__":
    main()
